﻿using System.Reflection;

#if UNITY_EDITOR
[assembly: AssemblyTitle("Netick")]
[assembly: AssemblyDescription("Networking Solution for Unity.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Karrar Rahim")]
[assembly: AssemblyProduct("Netick")]
[assembly: AssemblyCopyright("Karrar Rahim 2023")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
#endif
