Thank you for downloading Netick!

To get started, check out the samples in Samples. You have two samples:

1. Bomberman
2. FPS

In case you want an even more advanced sample, we got you covered! Check out our new Arena Shooter Sample: 
https://netick.net/arena-shooter-sample/

Helpful links:

* Discord: https://discord.com/invite/uV6bfG66Fx
* Docs: https://www.netick.net/docs.html
* Site: http://www.netick.net

If you have any questions, need support, or want to report a bug, visit our discord: 
https://discord.com/invite/uV6bfG66Fx

Please consider supporting us on Patreon so we are able to keep working on and improving Netick!
https://www.patreon.com/user?u=82493081

Enjoy!

Karrar,
Creator of Netick